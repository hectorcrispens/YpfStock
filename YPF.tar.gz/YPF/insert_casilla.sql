insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('A1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('A2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('A3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('A4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('A5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('A6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('B1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('B2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('B3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('B4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('B5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('B6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('C1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('C2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('C3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('C4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('C5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('C6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('D1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('D2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('D3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('D4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('D5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('D6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('E1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('E2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('E3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('E4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('E5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('E6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('F1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('F2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('F3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('F4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('F5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('F6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('G1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('G2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('G3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('G4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('G5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('G6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('H1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('H2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('H3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('H4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('H5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('H6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('I1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('I2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('I3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('I4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('I5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('I6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('J1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('J2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('J3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('J4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('J5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('J6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('K1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('K2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('K3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('K4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('K5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('K6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('L1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('L2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('L3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('L4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('L5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('L6', 55, 0);

insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M1', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M2', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M3', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M4', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M5', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M6', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M7', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M8', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M9', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M10', 55, 0);
insert into casillas (`nombre`, `lubricante`, `cantidad`) values ('M11', 55, 0);

