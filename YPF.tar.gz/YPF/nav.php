<div class="row">
    <div class="col-md-12">
<ul>
    <li><a href="ActualizarCasillas.php">Ingresar Valores</a></li>
    <li><a href="ActualizarLubricantes.php">Ingresar Lubricantes</a></li>
    <li><a href="procesador2.php">Ver Planilla</a></li>
    <li><a href="reporte.php">imprimir</a></li>
    <li><a href="buscador.php">buscar</a></li>
</ul>
    </div>
</div>